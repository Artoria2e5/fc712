FC712 Jan 21 Project
====================

Mingye Wang

I hereby declare that all code in this project is my own original work,
unless specifically marked.

(This document is converted by `pandoc` using the `mergedoc.sh` here.)

\newpage
